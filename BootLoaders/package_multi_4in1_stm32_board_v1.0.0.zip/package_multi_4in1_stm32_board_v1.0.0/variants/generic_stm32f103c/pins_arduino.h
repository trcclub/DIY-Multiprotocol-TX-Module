



// API compatibility
#include "variant.h"